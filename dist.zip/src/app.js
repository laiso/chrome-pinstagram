(function() {
  var Pinstagram, Upload;

  Pinstagram = (function() {

    function Pinstagram() {
      this.cookie = {};
    }

    return Pinstagram;

  })();

  Upload = (function() {

    function Upload() {}

    return Upload;

  })();

  this.Pinstagram = Pinstagram;

  this.Upload = Upload;

}).call(this);
